import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
   
  @Output() childData = new EventEmitter ;  //acceseing data from child by parent using output command and using eventbinding

  @Input() dataFromParent ='';     //accesing data from parent to child,using property binding
  constructor() { }

  ngOnInit() {
     this.childData.emit('This is data from child');
  }
}
