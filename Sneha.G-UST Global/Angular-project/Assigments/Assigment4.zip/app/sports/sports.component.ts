import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-sports',
  templateUrl: './sports.component.html',
  styleUrls: ['./sports.component.css']
})
export class SportsComponent implements OnInit {

countrySports:any [] =[];

  constructor(private http: HttpClient) {
    http.get<any>("https://newsapi.org/v2/top-headlines?category=sports&apiKey=8fc2cbf580db45ac883ac87df686deb0")
    .subscribe(resData => {
      this.countrySports = resData.articles;
    })
  }

  ngOnInit() {
  }

}
