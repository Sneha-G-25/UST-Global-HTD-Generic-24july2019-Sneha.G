import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApiTwoComponent } from './api-two.component';

describe('ApiTwoComponent', () => {
  let component: ApiTwoComponent;
  let fixture: ComponentFixture<ApiTwoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApiTwoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApiTwoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
