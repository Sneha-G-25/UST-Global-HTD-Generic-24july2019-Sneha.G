import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { HeaderComponent } from './header/header.component';
import { ApiComponent } from './api/api.component';
import { HomeComponent } from './home/home.component';
import { ApiTwoComponent } from './api-two/api-two.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    ApiComponent,
    HomeComponent,
    ApiTwoComponent,
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot([
      { path : '' , component : HomeComponent},
      { path : 'api' , component : ApiComponent},
      { path : 'header' , component : HeaderComponent},
      { path : 'api-two' , component : ApiTwoComponent}
    ]),
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
