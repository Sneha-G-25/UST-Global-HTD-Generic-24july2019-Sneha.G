import { Component, OnInit, Input} from '@angular/core';

@Component({
  selector: 'app-sub-car',
  templateUrl: './sub-car.component.html',
  styleUrls: ['./sub-car.component.css']
})
export class SubCarComponent implements OnInit {


  @Input() carData:any='';

  constructor() { }

  ngOnInit() {
  }

}
