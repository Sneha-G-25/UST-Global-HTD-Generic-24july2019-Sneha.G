import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-sub-mobile',
  templateUrl: './sub-mobile.component.html',
  styleUrls: ['./sub-mobile.component.css']
})
export class SubMobileComponent implements OnInit {

  @Input() cellPhone :any ="";

  constructor() { }

  ngOnInit() {
  }

}
