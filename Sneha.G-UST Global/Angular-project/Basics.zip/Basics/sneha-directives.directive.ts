import { Directive } from '@angular/core';

@Directive({
  selector: '[appSnehaDirectives]'
})
export class SnehaDirectivesDirective {
  

  constructor() { }

}
