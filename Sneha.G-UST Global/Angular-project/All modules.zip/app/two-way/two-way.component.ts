import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-two-way',
  templateUrl: './two-way.component.html',
  styleUrls: ['./two-way.component.css']
})
export class TwoWayComponent implements OnInit {

tag ="";
color = "blue";
normal ="pink";
change11 = "";
  send(data1)
  {
this.tag = data1;
  }

  change()
  {
    
      if(this.color=="blue")
    {
      this.color="green";
    }
    setTimeout(() => {
      this.color="pink";
    }, 3000);
    }
    send1()
    {
      if(this.normal=="pink")
      this.normal = "green"
      setTimeout(() => {
        this.normal="blue"
      }, 5000);
    }
    sendData(data10){
      this.change11 = data10;
      if(this.change11=="green")
      setTimeout(() => 
    {
      this.change11 ="orange";
    },2000);
    }
    

  constructor() { }

  ngOnInit() {
  }

}
