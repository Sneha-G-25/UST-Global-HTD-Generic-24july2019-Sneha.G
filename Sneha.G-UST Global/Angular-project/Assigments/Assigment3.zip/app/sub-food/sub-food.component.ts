import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-sub-food',
  templateUrl: './sub-food.component.html',
  styleUrls: ['./sub-food.component.css']
})
export class SubFoodComponent implements OnInit {

  @Input() recipe: any = '';
  constructor() { }

  ngOnInit() {
  }

}
