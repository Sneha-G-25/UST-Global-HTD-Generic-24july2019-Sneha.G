import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bikes',
  templateUrl: './bikes.component.html',
  styleUrls: ['./bikes.component.css']
})
export class BikesComponent implements OnInit {
  bikeData :any ='';
   bikes = [
            {
              name : 'antic',
              img  :'https://cdn.pixabay.com/photo/2015/05/28/23/12/auto-788747__340.jpg',
              description :'gjgjhjhkjhkkjkjjkjkjkjkjjkjkkjkj'
            },
            {
              name : 'Model',
              img : 'https://cdn.pixabay.com/photo/2014/09/07/22/34/car-race-438467__340.jpg',
              description : 'hgjhgjhjhjvxfgagadfahdfhvbavha'
            },
            {
              name : 'royal',
              img :'https://cdn.pixabay.com/photo/2017/09/01/20/23/ford-2705402__340.jpg',
              description :'sfdgfcgvhgjbmjkuiyuyrtfvcbvnbjhkjj'
            },
            {
              name : 'enfield',
              img : 'https://cdn.pixabay.com/photo/2015/10/12/15/05/car-984159__340.jpg',
              description :'ghgjhgjhgjhjhjgjhgjhkhkhjkjhkjksjifhsfhshfsuh',
            }
   ]
  constructor() { }
   sendBike(bike){
     this.bikeData = bike;
   }
  ngOnInit() {
  }

}
