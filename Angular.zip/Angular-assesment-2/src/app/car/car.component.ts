import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-car',
  templateUrl: './car.component.html',
  styleUrls: ['./car.component.css']
})
export class CarComponent implements OnInit {
  newCar:any ='';
  constructor() { }
  cars = [
    {
      brand :'Benz',
      img1 :'https://cdn.pixabay.com/photo/2016/12/03/18/57/amg-1880381__340.jpg',
      desc :'A car (or automobile) is a wheeled motor vehicle used for transportation. Most definitions of car say they run primarily on roads, seat one to eight people, have f tires, and mainly transport people rather than goods.[2][3]Cars came into global use during the 20th century, and developed economies depend on them. The year 1886 is regarded as the birth year of the modern car when German inventor Karl Benz patented his Benz Patent-Motorwagen. Cars became widely '
    },
    { brand :'Yello pardise',
    img1 :'https://cdn.pixabay.com/photo/2016/03/09/09/23/car-1245780__340.jpg',
    desc :'A car (or automobile) is a wheeled motor vehicle used for transportation. Most definitions of car say they run primarily on roads, seat one to eight people, have f tires, and mainly transport people rather than goods.[2][3]Cars came into global use during the 20th century, and developed economies depend on them. The year 1886 is regarded as the birth year of the modern car when German inventor Karl Benz patented his Benz Patent-Motorwagen. Cars became widely ' 
  },
  {
    brand :'red rcoky',
    img1 : 'https://cdn.pixabay.com/photo/2016/12/07/21/50/audi-1890494__340.jpg',
    desc :'A car (or automobile) is a wheeled motor vehicle used for transportation. Most definitions of car say they run primarily on roads, seat one to eight people, have f tires, and mainly transport people rather than goods.[2][3]Cars came into global use during the 20th century, and developed economies depend on them. The year 1886 is regarded as the birth year of the modern car when German inventor Karl Benz patented his Benz Patent-Motorwagen. Cars became widely ' 
  },
  {
    brand :'smoky-look',
    img1 : 'https://cdn.pixabay.com/photo/2015/05/28/23/12/auto-788747__340.jpg',
    desc :'A car (or automobile) is a wheeled motor vehicle used for transportation. Most definitions of car say they run primarily on roads, seat one to eight people, have f tires, and mainly transport people rather than goods.[2][3]Cars came into global use during the 20th century, and developed economies depend on them. The year 1886 is regarded as the birth year of the modern car when German inventor Karl Benz patented his Benz Patent-Motorwagen. Cars became widely '
  }
  ]
  sendCar(car){
    this.newCar = car;  
  }


  ngOnInit() {
  }

}
