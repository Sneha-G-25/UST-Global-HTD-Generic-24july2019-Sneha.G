import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-two-way',
  templateUrl: './two-way.component.html',
  styleUrls: ['./two-way.component.css']
})
export class TwoWayComponent implements OnInit  {
backgroundColour ='red';

  constructor() {
    console.log('constructor is running')  //constructor is runnig before oninit interfacecccccccs
  }
    // buttonEvent(data){
    //   console.log(data);
    // }

     changeColour() {
       if (this.backgroundColour === 'red') {
       this.backgroundColour = 'blue';
     } else {
       this.backgroundColour = 'red';
      }
     }
     backgroundColour1 = 'green';

    changeColour1(data){
     this.backgroundColour1 =data;
    }
  ngOnInit(): void {
    console.log('ngoninit implemented')
  }

}
