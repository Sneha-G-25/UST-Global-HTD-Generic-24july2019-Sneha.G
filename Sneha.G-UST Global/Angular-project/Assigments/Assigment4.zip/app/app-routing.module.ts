import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { NewsComponent } from './news/news.component';
import { SportsComponent } from './sports/sports.component';
import { EntertainmentComponent } from './entertainment/entertainment.component';
import { Header1Component } from './header1/header1.component';
import { GitAppComponent } from './git-app/git-app.component';



const routes: Routes = [
  { path : '', component: HomeComponent},
  { path : 'news', component : NewsComponent},
  { path : 'sports', component: SportsComponent},
  { path : 'entertainment' , component : EntertainmentComponent},
  { path : 'git-app', component : GitAppComponent},
  { path : 'header1' , component: Header1Component}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
