import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { CarComponent } from './car/car.component';
import { SubCarComponent } from './sub-car/sub-car.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    CarComponent,
    SubCarComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot([
  { path : '' , component : HomeComponent},
{ path : 'car', component : CarComponent},
{ path : 'sub_car', component: SubCarComponent}])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
