import { Component, OnInit } from '@angular/core';
import { NgForm} from '@angular/forms' ;

@Component({
  selector: 'app-add-tasks',
  templateUrl: './add-tasks.component.html',
  styleUrls: ['./add-tasks.component.css']
})
export class AddTasksComponent implements OnInit {
input :any =[];
  constructor() { }
  printForm(listForm:NgForm){
    this.input.push(listForm.value);
 listForm.reset();
 console.log(this.input);

  }

  ngOnInit() {
  }

}
