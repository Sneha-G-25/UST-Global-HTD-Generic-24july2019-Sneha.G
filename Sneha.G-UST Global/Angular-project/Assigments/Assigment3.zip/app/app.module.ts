import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { CarComponent } from './car/car.component';
import { SubCarComponent } from './sub-car/sub-car.component';
import { MobileComponent } from './mobile/mobile.component';
import { SubMobileComponent } from './sub-mobile/sub-mobile.component';
import { FoodComponent } from './food/food.component';
import { SubFoodComponent } from './sub-food/sub-food.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    CarComponent,
    SubCarComponent,
    MobileComponent,
    SubMobileComponent,
    FoodComponent,
    SubFoodComponent,
    
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot([
      { path : 'car', component :CarComponent },
      { path : 'sub-car', component: SubCarComponent},
      { path :'food', component : FoodComponent},
      { path : 'sub-food', component: SubFoodComponent},
      { path :  'mobile', component : MobileComponent},
      { path : 'sub-mobile',component : SubMobileComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
