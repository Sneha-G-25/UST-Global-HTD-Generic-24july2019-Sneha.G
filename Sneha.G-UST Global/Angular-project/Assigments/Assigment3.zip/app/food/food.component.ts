import { Component, OnInit } from '@angular/core';
import { isLoweredSymbol } from '@angular/compiler';

@Component({
  selector: 'app-food',
  templateUrl: './food.component.html',
  styleUrls: ['./food.component.css']
})
export class FoodComponent implements OnInit {

  lunch: any = '';
  items = [
    {
      name: 'Burger',
      picture : 'https://cdn.pixabay.com/photo/2016/03/05/19/02/hamburger-1238246__340.jpg',
      desc : 'What is yummy that is ment to be food, but also we get great food out their who can make miracles for health'
    },

    {
      name: 'Pizza',
      picture : 'https://cdn.pixabay.com/photo/2017/12/10/14/47/piza-3010062__340.jpg',
      desc : 'What is yummy that is ment to be food, but also we get great food out their who can make miracles for health'
    },

    {
      name: 'Cake',
      picture : 'https://cdn.pixabay.com/photo/2017/01/11/11/33/cake-1971552_960_720.jpg',
      desc : 'What is yummy that is ment to be food, but also we get great food out their who can make miracles for health'
    },

    {
      name: 'Pancake',
      picture: 'https://cdn.pixabay.com/photo/2017/01/16/17/45/pancake-1984716__340.jpg',
      desc : 'What is yummy that is ment to be food, but also we get great food out their who can make miracles for health'
    }
  ] ;

  constructor() { }
  sendFood(yumm)
  {
    this.lunch = yumm;
  }

  ngOnInit() {
  }

}
