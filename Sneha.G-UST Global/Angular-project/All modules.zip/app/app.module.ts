import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms' ;
import { RouterModule } from '@angular/router';
import { HttpClientModule} from '@angular/common/http';



import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { FormComponent } from './form/form.component';
import { DataBindingComponent } from './data-binding/data-binding.component';
import { TwoWayComponent } from './two-way/two-way.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { DirectivesComponent } from './directives/directives.component';
import { ApiComponent } from './api/api.component';
import { PractiseFormComponent } from './practise-form/practise-form.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    FormComponent,
    DataBindingComponent,
    TwoWayComponent,
    ParentComponent,
    ChildComponent,
    DirectivesComponent,
    ApiComponent,
    PractiseFormComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot([
      { path : '' , component : HomeComponent},
      { path : 'form' , component : FormComponent},
      { path :'two-way', component :TwoWayComponent},
      { path : 'directives', component: DirectivesComponent},
      { path : 'parent' , component : ParentComponent , children :[
        { path : 'child' , component: ChildComponent}
      ]},
      { path : 'api' , component: ApiComponent},
      { path : 'practise-form', component: PractiseFormComponent}
    ]),
   HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
