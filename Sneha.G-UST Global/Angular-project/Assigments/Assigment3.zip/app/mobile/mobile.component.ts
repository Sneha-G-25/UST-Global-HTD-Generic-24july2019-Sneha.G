import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mobile',
  templateUrl: './mobile.component.html',
  styleUrls: ['./mobile.component.css']
})
export class MobileComponent implements OnInit {

  phone:any ="";

  mobile = [ {
      brand : 'samsung',
      img :'https://cdn.pixabay.com/photo/2017/08/05/22/41/mobile-2586295__340.jpg',
      desc :' In the 21st century, a new type of mobile phone, called smartphones, have become popular. Now, more people are using smartphones',
             } ,
             { 
               brand :'intex',
               img :'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR-mU5z16TyBJtf8uCtkth0vB8L2RfJvVEwLp32Uir2qqPhlTeMlQ',
               desc : 'In the 21st century, a new type of mobile phone, called smartphones, have become popular. Now, more people are using smartphones',
               },
               {
                brand : 'sony',
                img : 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQPWrRoC6GDimPWM4GECmTS_sKqHcgsXD-J28PSuoSLifFBx8feXQ',
                desc : 'In the 21st century, a new type of mobile phone, called smartphones, have become popular. Now, more people are using smartphones',
              }
]

  constructor() { }
  sendMobile(mob){
    
    this.phone=mob;
  }

  ngOnInit() {
  }

}
