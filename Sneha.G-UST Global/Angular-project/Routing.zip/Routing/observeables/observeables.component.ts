import { Component, OnInit, OnDestroy } from '@angular/core';
import { UserService } from '../user.service';
// import { interval, Subscription } from 'rxjs';
// import { map } from 'rxjs/operators'

@Component({
  selector: 'app-observeables',
  templateUrl: './observeables.component.html',
  styleUrls: ['./observeables.component.css']
})
export class ObserveablesComponent implements OnInit, OnDestroy {
//  MySubscription: Subscription ;
  constructor(private userService : UserService) {    //creating the services

  } 

  ngOnInit() {
    
  // this.MySubscription = interval(1000). pipe(map(data =>{
  //    return data*10;
  //  })).subscribe (data => {
  //    console.log(data);
  //  },  err =>{
  //    console.log(err);
  //  },() =>{
  //    console.log('sunscription complete')
  //  });
  this.userService.printDetails();
  }

  ngOnDestroy(){
     
    // this.MySubscription.unsubscribe();
  }
}
