import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-binding',
  templateUrl: './data-binding.component.html',
  styleUrls: ['./data-binding.component.css']
})
export class DataBindingComponent {
name = 'sneha';
textClasses = 'bg-success text-white';
paragraphStyle = true;
imgURL ="http://";//cpy img url  as save as
redcolour = true;
padding ="50px";
colSpan = 2;
  constructor() { 
    setTimeout(() => {
      this.redcolour = false;
   this.paragraphStyle= false;
  },5000);
}
}
