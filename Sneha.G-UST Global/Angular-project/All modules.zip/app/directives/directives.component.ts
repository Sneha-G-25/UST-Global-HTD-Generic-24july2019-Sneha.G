import { Component, OnInit } from '@angular/core';
import { splitClasses } from '@angular/compiler';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent implements OnInit {

  name ="sneha";
  condition= false ;
  group1 = ['bg bg-sucess', 'col-md-6','offset-md-3','form-control'];  
  group2 = 'text-center';

  index = ['name','age','color'];

  removeUser(index){
  let value = this.index.indexOf(index);
  this.index.splice(value,1);
  this.condition=true;

  }
  print(data){
    console.log(data);
  }

  constructor() { }

  ngOnInit() {
  }

}
