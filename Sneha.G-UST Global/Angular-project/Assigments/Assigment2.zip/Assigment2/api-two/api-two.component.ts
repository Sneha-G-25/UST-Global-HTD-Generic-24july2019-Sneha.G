import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-api-two',
  templateUrl: './api-two.component.html',
  styleUrls: ['./api-two.component.css']
})
export class ApiTwoComponent implements OnInit {

  github: any [] = [];

  constructor(private http: HttpClient) {
    http.get<any>(`http://jsonplaceholder.typicode.com/posts`)
    .subscribe(resData => {
      this.github = resData;
    }) ;
  }

  ngOnInit() {
  }

}
