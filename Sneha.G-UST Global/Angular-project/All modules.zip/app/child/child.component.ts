import { Component, OnInit, Input,EventEmitter , Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  @Output() event = new EventEmitter ;
@Input()  calName = "";
  constructor() { }
  sendInfo(data1)
  {
    this.event.emit(data1);
  }

  ngOnInit() {
    // this.sendData.emit("hi grt job");
  }

}
