import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
   input : any = [];
  constructor() { }
printForm(regForm : NgForm){

  console.log(regForm.value);

 this.input.push(regForm.value);
 regForm.reset();
 
 console.log(this.input);

}
  ngOnInit() {
  }

}
// printForm(regForm :NgForm)
// {
//   console.log(regForm.value)
//   this.Input.push(regForm.value);
//   regForm.reset();
//   console.log(this.input)
// }
