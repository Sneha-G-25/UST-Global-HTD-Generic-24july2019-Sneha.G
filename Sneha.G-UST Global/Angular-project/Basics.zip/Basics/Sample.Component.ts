import { Component } from '@angular/core';


@Component({
    selector: 'app-sample',
   templateUrl :'./Sample.Component.html',
   styleUrls :['./Sample.Component.css']
})

export class SampleComponent {

}