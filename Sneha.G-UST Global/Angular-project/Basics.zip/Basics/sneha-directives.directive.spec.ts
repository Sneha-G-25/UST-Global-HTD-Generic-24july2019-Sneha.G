import { SnehaDirectivesDirective } from './sneha-directives.directive';

describe('SnehaDirectivesDirective', () => {
  it('should create an instance', () => {
    const directive = new SnehaDirectivesDirective();
    expect(directive).toBeTruthy();
  });
});
