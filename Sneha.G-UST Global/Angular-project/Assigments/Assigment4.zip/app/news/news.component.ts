import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {

  
  countryNews:any [] =[];

  constructor(private http: HttpClient) {
    http.get<any>("https://newsapi.org/v2/top-headlines?country=us&apiKey=8fc2cbf580db45ac883ac87df686deb0")
    .subscribe(resData => {
      this.countryNews= resData.articles;
    })
  }

  ngOnInit() {
  }

}
