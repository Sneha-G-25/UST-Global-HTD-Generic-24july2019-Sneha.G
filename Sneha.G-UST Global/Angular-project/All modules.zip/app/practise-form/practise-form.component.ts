import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { resetFakeAsyncZone } from '@angular/core/testing';

@Component({
  selector: 'app-practise-form',
  templateUrl: './practise-form.component.html',
  styleUrls: ['./practise-form.component.css']
})
export class PractiseFormComponent implements OnInit {
array:any [] = [];
  print(formName :NgForm)
  {
  console.log(formName.value);
  this.array.push(formName.value);
  formName.reset();
  console.log(this.array.values);

  }

  constructor() { }

  ngOnInit() {
  }

}
