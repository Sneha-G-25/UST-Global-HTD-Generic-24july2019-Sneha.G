import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-git-app',
  templateUrl: './git-app.component.html',
  styleUrls: ['./git-app.component.css']
})
export class GitAppComponent implements OnInit {

jsonNews: any [] = [];

  constructor(private http: HttpClient) {
    http.get <any> ( "http://jsonplaceholder.typicode.com/posts " )
    .subscribe(resData => {
      this.jsonNews = resData.articles;
    });
  }

  ngOnInit() {
  }

}
