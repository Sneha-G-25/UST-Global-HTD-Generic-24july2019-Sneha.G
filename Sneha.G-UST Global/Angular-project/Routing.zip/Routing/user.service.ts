import { Injectable } from '@angular/core';

@Injectable({
    providedIn:"root"
})
export class UserService{
    users=[
        {
            name:'sneha',
            company :'UST'
        },
        {
            name :'manu',
            company :'Test yanthra'
        }
    ]
printDetails(){
    console.log("the function present inservice is running");
}

}