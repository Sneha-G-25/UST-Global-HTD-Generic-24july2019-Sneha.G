import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubMobileComponent } from './sub-mobile.component';

describe('SubMobileComponent', () => {
  let component: SubMobileComponent;
  let fixture: ComponentFixture<SubMobileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubMobileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubMobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
