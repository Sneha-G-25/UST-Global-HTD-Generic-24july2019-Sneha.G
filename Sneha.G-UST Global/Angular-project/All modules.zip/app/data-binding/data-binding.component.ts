import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-binding',
  templateUrl: './data-binding.component.html',
  styleUrls: ['./data-binding.component.css']
})
export class DataBindingComponent implements OnInit {


  name = "suma" ;
  class_binding = "bg bg-info col-md-4";
  key = "password";
  url = "https://cdn.pixabay.com/photo/2019/08/30/21/16/mountains-4442337_960_720.jpg";
  condition = true;
  redcolour = true;
  style="green";
  new = 'orange';
  hero = "20px"
  xgg="20px";
  colspan =3;

  constructor() {
    setTimeout(() => { 
     
      this.style = 'pink';
      this.condition= false ;
     
    }, 2000);
   }

  ngOnInit() {
  }
}
